# Grammar Nazi Powercord Port

Swish's GrammarNazi ported to Powercord.

A Powercord plugin that automatically punctuates, capitalizes, and spellchecks your sentences.

## Features

- Capitalizes the first letter of every sentence.
- Adds proper punctuation at the end of every sentence.
- Customizable dictionary interactable through chat commands.
- A button in the channel area container to quickly toggle.

### Installation

For installation, go to **Plugins -> Open a CMD / Powershell / Terminal / Gitbash** in the folder, and enter the following:

```sh
git clone https://github.com/VenPlugs/grammar-nazi
```
