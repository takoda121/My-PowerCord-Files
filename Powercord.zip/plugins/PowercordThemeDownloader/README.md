# ThemeDownloader

This plugin lets you install a theme from a URL, and adds a button to download the theme

## Support Server
[![Discord Server](https://discordapp.com/api/guilds/754130139415183401/widget.png?style=banner2)](https://discord.gg/Cka4prH)
