# pc-stafftags

Displays owner, admin, and staff tags similar to bot tags, they can appear in the member list and/or chat.

| Preview                              | Settings                             |
| ------------------------------------ | ------------------------------------ |
| ![](https://i.imgur.com/4x8dnFA.png) | ![](https://i.imgur.com/seVBXw1.png) |
| ![](https://i.imgur.com/6NwdauH.png) |                                      |

---

dis is my first plugin, be kind plz <3
