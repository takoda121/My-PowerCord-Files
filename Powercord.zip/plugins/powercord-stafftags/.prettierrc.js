module.exports = {
    singleQuote: true,
    jsxSingleQuote: true,
    trailingComma: "none",
    useTabs: false,
    tabWidth: 4,
    semi: true,
    arrowParens: "avoid",
};
