# Nitro Bypass

Send emojis and screen share in high quality without Discord Nitro

# Powercord Guideline
[![Do not attempt to circumvent permissions](https://user-images.githubusercontent.com/13122796/152648190-6a3b7610-62d2-492d-8569-7f43dcd152ce.jpeg)](https://powercord.dev/guidelines)

# Discord ToS
[![Client mods are against the ToS](https://user-images.githubusercontent.com/13122796/152648311-438de9cd-3baa-4f0a-b3cf-6ae635143fce.jpeg)](https://twitter.com/discord/status/1042341021273743360)
